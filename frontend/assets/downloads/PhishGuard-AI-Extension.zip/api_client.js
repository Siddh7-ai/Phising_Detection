// API Client - Backend ML Only
// Fixed: retry logic, longer timeout, exponential backoff for Render cold starts

import CONFIG from './config.js';

class APIClient {
  constructor() {
    this.cache = new Map();
  }

  getCached(url) {
    const cached = this.cache.get(url);
    if (!cached) return null;
    const age = Date.now() - cached.timestamp;
    if (age > CONFIG.CACHE_TTL_MS) {
      this.cache.delete(url);
      return null;
    }
    return cached.result;
  }

  setCached(url, result) {
    this.cache.set(url, { result, timestamp: Date.now() });
    if (this.cache.size > 100) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }
  }

  /**
   * Single fetch attempt with its own timeout
   */
  async _fetchOnce(url, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const response = await fetch(CONFIG.API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
        signal: controller.signal
      });

      clearTimeout(timer);

      if (!response.ok) throw new Error(`Backend error: ${response.status}`);

      return await response.json();
    } catch (err) {
      clearTimeout(timer);
      throw err;
    }
  }

  /**
   * Scan URL with retry + exponential backoff.
   * Render free tier can take 15-30s to cold-start — we retry up to 3 times.
   *
   * Attempt timeouts: 15s → 20s → 25s
   * Delays between retries: 1s → 2s
   */
  async scanURL(url) {

    // Skip internal/browser pages
    try {
      const urlObj = new URL(url);
      const scheme = urlObj.protocol;
      if (scheme === 'chrome:' || scheme === 'chrome-extension:' || scheme === 'about:' || scheme === 'file:') {
        console.log('⏭ Skipping internal/browser page:', url);
        return {
          url, classification: 'Legitimate',
          confidence: 0, risk_level: 'low', skipped: true
        };
      }
    } catch (e) {
      console.warn('URL parse error:', e);
    }

    // Check cache first
    const cached = this.getCached(url);
    if (cached) {
      console.log('⚡ Using cached result for:', url);
      return cached;
    }

    const attempts    = [15000, 20000, 25000]; // timeout per attempt
    const retryDelays = [1000, 2000];           // ms to wait between attempts

    let lastError = null;

    for (let i = 0; i < attempts.length; i++) {
      try {
        console.log(`🔍 Scan attempt ${i + 1}/${attempts.length} for: ${url} (timeout: ${attempts[i] / 1000}s)`);

        const result = await this._fetchOnce(url, attempts[i]);
        this.setCached(url, result);

        if (i > 0) console.log(`✅ Succeeded on attempt ${i + 1}`);
        return result;

      } catch (err) {
        lastError = err;

        if (err.name === 'AbortError') {
          console.warn(`⏱ Attempt ${i + 1} timed out after ${attempts[i] / 1000}s`);
        } else {
          console.warn(`❌ Attempt ${i + 1} failed:`, err.message);
        }

        // Wait before retrying (except after the last attempt)
        if (i < retryDelays.length) {
          console.log(`⏳ Retrying in ${retryDelays[i] / 1000}s...`);
          await new Promise(res => setTimeout(res, retryDelays[i]));
        }
      }
    }

    // All attempts exhausted — fail open (allow navigation, do not block)
    console.error('❌ All scan attempts failed. Failing open for:', url, lastError);
    return {
      url,
      classification: 'Error',
      confidence: 0,
      risk_level: 'unknown',
      error: true,
      errorMessage: lastError?.message || 'Request failed after 3 attempts'
    };
  }

  clearCache() {
    this.cache.clear();
  }
}

const apiClient = new APIClient();
export default apiClient;
