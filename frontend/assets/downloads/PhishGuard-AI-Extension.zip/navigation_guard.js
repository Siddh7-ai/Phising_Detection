// Navigation Guard - Block Phishing Sites Based on Backend

import apiClient from './api_client.js';

class NavigationGuard {
  constructor() {
    this.pendingNavigations = new Set();
    this.blockedTabs = new Set();       // prevents re-block loop during redirect

    // Tab-scoped bypass: Map<tabId, Set<url>>
    // In-memory only — automatically cleared when tab closes.
    this.tabAllowlist = new Map();
  }

  init() {
    // onCommitted fires AFTER the navigation is committed — more reliable than
    // onBeforeNavigate for catching all navigation types (link clicks, address bar,
    // redirects, etc.) and still early enough to redirect before page content renders.
    chrome.webNavigation.onCommitted.addListener(
      (details) => this.handleNavigation(details),
      { url: [{ schemes: ['http', 'https'] }] }
    );

    // Clean up allowlist when tab is closed
    chrome.tabs.onRemoved.addListener((tabId) => {
      if (this.tabAllowlist.has(tabId)) {
        this.tabAllowlist.delete(tabId);
        console.log('🗑 Cleared tab bypass on tab close, tabId:', tabId);
      }
      // Also clean up blocked state
      this.blockedTabs.delete(tabId);
    });

    console.log('✓ Navigation guard initialized');
  }

  allowUrlForTab(tabId, url) {
    if (!this.tabAllowlist.has(tabId)) {
      this.tabAllowlist.set(tabId, new Set());
    }
    this.tabAllowlist.get(tabId).add(url);
    console.log(`✅ Tab ${tabId} bypass granted for: ${url}`);
  }

  async handleNavigation(details) {
    // Only intercept main frame
    if (details.frameId !== 0) return;

    const url   = details.url;
    const tabId = details.tabId;

    // Skip extension-internal navigations (e.g. blocked.html itself)
    if (url.startsWith('chrome-extension://') || url.startsWith('chrome://')) return;

    // Skip if this tab is being redirected to the blocked page right now
    if (this.blockedTabs.has(tabId)) {
      console.log('⏭ Skipping re-check for tab being redirected:', tabId);
      return;
    }

    // Skip if user explicitly bypassed this URL for this tab
    const tabUrls = this.tabAllowlist.get(tabId);
    if (tabUrls && tabUrls.has(url)) {
      console.log(`✅ Tab-bypass active for tab ${tabId}, skipping scan: ${url}`);
      return;
    }

    // Deduplicate — skip if already scanning same tab+url
    const navigationKey = `${tabId}-${url}`;
    if (this.pendingNavigations.has(navigationKey)) {
      console.log('⏭ Already scanning:', navigationKey);
      return;
    }

    this.pendingNavigations.add(navigationKey);

    try {
      console.log('🔍 Checking navigation:', url);

      const result = await apiClient.scanURL(url);

      // Only block on definitive Phishing — never block on Error/timeout
      if (result.classification === 'Phishing') {
        console.log('🚫 BLOCKING - Phishing detected:', url);
        await this.blockNavigation(tabId, url, result);
      } else {
        console.log(`✓ ALLOWING (${result.classification}):`, url);
      }

    } catch (error) {
      // Unexpected error — fail open (allow navigation)
      console.error('✗ Navigation check error (fail open):', error);
    } finally {
      // Remove from pending after a delay to handle quick re-navigations
      setTimeout(() => {
        this.pendingNavigations.delete(navigationKey);
      }, 3000);
    }
  }

  async blockNavigation(tabId, url, result) {
    try {
      this.blockedTabs.add(tabId);

      await chrome.storage.local.set({
        lastDetection: {
          url:            url,
          originalUrl:    url,
          classification: result.classification,
          confidence:     result.confidence  ?? 95,
          risk_level:     result.risk_level  ?? 'high',
          modules:        result.modules     || {},
          timestamp:      Date.now()   // always epoch ms — blocked_page.js handles both formats
        }
      });

      const blockedPageUrl = chrome.runtime.getURL('blocked.html');
      await chrome.tabs.update(tabId, { url: blockedPageUrl });

      console.log('→ Redirected to blocked page for:', url);

    } catch (error) {
      console.error('✗ Error blocking navigation:', error);
      this.blockedTabs.delete(tabId);
    } finally {
      // Release redirect lock after 4s (slightly longer to cover slower systems)
      setTimeout(() => {
        this.blockedTabs.delete(tabId);
      }, 4000);
    }
  }
}

const navigationGuard = new NavigationGuard();
export default navigationGuard;
